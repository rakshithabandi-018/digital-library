import 'package:flutter/material.dart';

void main() {
  runApp(const DigitalLibraryApp());
}

// ============================================================
// APP
// ============================================================

class DigitalLibraryApp extends StatelessWidget {
  const DigitalLibraryApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Digital Library',
      theme: ThemeData(
        primarySwatch: Colors.indigo,
        scaffoldBackgroundColor: const Color(0xffF5F7FB),
        fontFamily: 'Arial',
      ),
      home: const MainScreen(),
    );
  }
}

// ============================================================
// TOPIC MODEL
// ============================================================

class Topic {
  final String title;
  final String content;

  Topic({
    required this.title,
    required this.content,
  });
}

// ============================================================
// BOOK MODEL
// ============================================================

class Book {
  final String title;
  final String author;
  final String category;
  final String description;
  final String image;
  final double rating;
  final List<Topic> topics;

  Book({
    required this.title,
    required this.author,
    required this.category,
    required this.description,
    required this.image,
    required this.rating,
    required this.topics,
  });
}

// ============================================================
// BOOK DATA
// ============================================================

final List<Book> books = [

  // ----------------------------------------------------------
  // FLUTTER
  // ----------------------------------------------------------

  Book(
    title: 'Flutter Basics',
    author: 'John Smith',
    category: 'Programming',
    description:
        'Learn the fundamentals of Flutter and Dart. This book is useful for beginners who want to build mobile applications.',
    image: 'https://picsum.photos/seed/flutter/300/400',
    rating: 4.8,
    topics: [
      Topic(
        title: 'Introduction to Flutter',
        content:
            'Flutter is an open-source UI framework developed by Google. It is used to create applications for Android, iOS, web and desktop using a single codebase.',
      ),
      Topic(
        title: 'Dart Programming',
        content:
            'Dart is the programming language used by Flutter. It supports variables, functions, classes, objects and asynchronous programming.',
      ),
      Topic(
        title: 'Widgets',
        content:
            'Widgets are the basic building blocks of Flutter applications. Text, buttons, images, rows and columns are examples of widgets.',
      ),
    ],
  ),

  // ----------------------------------------------------------
  // PYTHON
  // ----------------------------------------------------------

  Book(
    title: 'Python Programming',
    author: 'David Lee',
    category: 'Programming',
    description:
        'A simple introduction to Python programming covering variables, operators, conditions, loops, functions, lists, dictionaries and object-oriented programming.',
    image: 'https://picsum.photos/seed/python/300/400',
    rating: 4.7,
    topics: [

      Topic(
        title: 'Introduction to Python',
        content:
            'Python is a high-level, interpreted and general-purpose programming language. It is easy to learn because it has a simple and readable syntax. Python is widely used in web development, data science, artificial intelligence, machine learning, automation and software development.',
      ),

      Topic(
        title: 'Variables and Data Types',
        content:
            'Variables are used to store data in Python. Python supports several data types such as integer, float, string, boolean, list, tuple, set and dictionary. Example: name = "Rahul" and age = 20.',
      ),

      Topic(
        title: 'Operators',
        content:
            'Operators are symbols used to perform operations on values. Python provides arithmetic operators, relational operators, logical operators, assignment operators and bitwise operators.',
      ),

      Topic(
        title: 'Conditional Statements',
        content:
            'Conditional statements are used to make decisions in a program. Python provides if, elif and else statements. These statements execute different blocks of code depending on whether a condition is true or false.',
      ),

      Topic(
        title: 'Loops',
        content:
            'Loops are used to execute a block of code repeatedly. Python provides for loops and while loops. A for loop is commonly used to iterate over a sequence, while a while loop continues executing as long as a condition is true.',
      ),

      Topic(
        title: 'Functions',
        content:
            'A function is a reusable block of code that performs a particular task. Functions are defined using the def keyword. They can accept parameters and return values. Functions help make programs organized and reusable.',
      ),

      Topic(
        title: 'Lists',
        content:
            'A list is an ordered and mutable collection in Python. Lists can contain different types of values. Example: numbers = [10, 20, 30, 40]. Elements of a list can be added, removed and modified.',
      ),

      Topic(
        title: 'Tuples',
        content:
            'A tuple is an ordered collection that cannot be modified after creation. Tuples are generally written using parentheses. Example: numbers = (10, 20, 30).',
      ),

      Topic(
        title: 'Dictionaries',
        content:
            'A dictionary stores data in key-value pairs. Dictionaries are useful for representing structured information. Example: student = {"name": "Rahul", "age": 20}.',
      ),

      Topic(
        title: 'Sets',
        content:
            'A set is an unordered collection of unique elements. Sets are useful when duplicate values need to be removed. Example: numbers = {10, 20, 30}.',
      ),

      Topic(
        title: 'Object Oriented Programming',
        content:
            'Object-oriented programming organizes programs using classes and objects. Important concepts include classes, objects, inheritance, polymorphism, encapsulation and abstraction.',
      ),

      Topic(
        title: 'Exception Handling',
        content:
            'Exception handling is used to handle errors during program execution. Python provides try, except, else and finally blocks to manage exceptions and prevent unexpected program termination.',
      ),

      Topic(
        title: 'File Handling',
        content:
            'File handling allows Python programs to create, read, write and modify files. The open() function is commonly used to work with files.',
      ),

      Topic(
        title: 'Modules and Packages',
        content:
            'Modules are Python files containing functions, classes or variables that can be reused in other programs. Packages are collections of related modules.',
      ),
    ],
  ),

  // ----------------------------------------------------------
  // DATA STRUCTURES
  // ----------------------------------------------------------

  Book(
    title: 'Data Structures',
    author: 'Robert Brown',
    category: 'Computer Science',
    description:
        'Understand arrays, linked lists, stacks, queues, trees, graphs and important algorithms.',
    image: 'https://picsum.photos/seed/datastructure/300/400',
    rating: 4.6,
    topics: [
      Topic(
        title: 'Arrays',
        content:
            'Arrays store a collection of elements in an organized manner. They provide efficient access to elements using indexes.',
      ),
      Topic(
        title: 'Linked Lists',
        content:
            'A linked list is a linear data structure where elements are stored in nodes. Each node contains data and a reference to another node.',
      ),
      Topic(
        title: 'Stacks',
        content:
            'A stack is a linear data structure that follows the Last In First Out principle. Common operations are push, pop and peek.',
      ),
      Topic(
        title: 'Queues',
        content:
            'A queue is a linear data structure that follows the First In First Out principle. Common operations are enqueue and dequeue.',
      ),
      Topic(
        title: 'Trees',
        content:
            'A tree is a hierarchical data structure consisting of nodes connected by edges. Binary trees and binary search trees are common examples.',
      ),
      Topic(
        title: 'Graphs',
        content:
            'Graphs consist of vertices and edges. They are used to represent networks, relationships and connections between objects.',
      ),
    ],
  ),

  // ----------------------------------------------------------
  // DATABASE
  // ----------------------------------------------------------

  Book(
    title: 'Database Systems',
    author: 'Michael Johnson',
    category: 'Database',
    description:
        'Learn database concepts, SQL, relational databases, normalization and database management systems.',
    image: 'https://picsum.photos/seed/database/300/400',
    rating: 4.5,
    topics: [
      Topic(
        title: 'Introduction to Databases',
        content:
            'A database is an organized collection of data. Database Management Systems are used to store, manage and retrieve data efficiently.',
      ),
      Topic(
        title: 'SQL',
        content:
            'SQL stands for Structured Query Language. It is used to create, retrieve, update and delete data in relational databases.',
      ),
      Topic(
        title: 'Keys',
        content:
            'Keys are used to identify records and establish relationships between tables. Common keys include primary keys and foreign keys.',
      ),
      Topic(
        title: 'Normalization',
        content:
            'Normalization is the process of organizing database tables to reduce data redundancy and improve data consistency.',
      ),
      Topic(
        title: 'Transactions',
        content:
            'A transaction is a sequence of database operations performed as a single logical unit. Transactions help maintain database consistency.',
      ),
    ],
  ),

  // ----------------------------------------------------------
  // NETWORKS
  // ----------------------------------------------------------

  Book(
    title: 'Computer Networks',
    author: 'James Wilson',
    category: 'Networking',
    description:
        'Explore computer networking concepts including LAN, WAN, protocols, TCP/IP, routing and network security.',
    image: 'https://picsum.photos/seed/network/300/400',
    rating: 4.4,
    topics: [
      Topic(
        title: 'Introduction to Computer Networks',
        content:
            'A computer network is a collection of interconnected devices that communicate and share resources with each other.',
      ),
      Topic(
        title: 'OSI Model',
        content:
            'The OSI model consists of seven layers: Physical, Data Link, Network, Transport, Session, Presentation and Application.',
      ),
      Topic(
        title: 'TCP/IP Model',
        content:
            'The TCP/IP model is a networking model used for communication over the Internet. It includes Application, Transport, Internet and Network Access layers.',
      ),
      Topic(
        title: 'Routing',
        content:
            'Routing is the process of selecting a path for data packets to travel from the source device to the destination device.',
      ),
      Topic(
        title: 'Network Security',
        content:
            'Network security protects networks and data from unauthorized access, attacks and other security threats.',
      ),
    ],
  ),

  // ----------------------------------------------------------
  // OPERATING SYSTEMS
  // ----------------------------------------------------------

  Book(
    title: 'Operating Systems',
    author: 'William Clark',
    category: 'Computer Science',
    description:
        'Learn processes, memory management, file systems, scheduling and other operating system concepts.',
    image: 'https://picsum.photos/seed/os/300/400',
    rating: 4.6,
    topics: [
      Topic(
        title: 'Introduction to Operating Systems',
        content:
            'An operating system is system software that manages computer hardware and provides services to application programs.',
      ),
      Topic(
        title: 'Processes',
        content:
            'A process is a program that is currently executing. Process management includes process creation, scheduling and termination.',
      ),
      Topic(
        title: 'CPU Scheduling',
        content:
            'CPU scheduling determines which process gets access to the CPU. Common algorithms include FCFS, SJF, Priority and Round Robin.',
      ),
      Topic(
        title: 'Memory Management',
        content:
            'Memory management controls and coordinates the use of computer memory. Techniques include paging and segmentation.',
      ),
      Topic(
        title: 'File Systems',
        content:
            'A file system organizes and manages files and directories on storage devices. It provides methods for storing and accessing data.',
      ),
    ],
  ),
];

// ============================================================
// MAIN SCREEN
// ============================================================

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int currentIndex = 0;

  final List<Widget> pages = const [
    HomePage(),
    SearchPage(),
    FavoritesPage(),
    ProfilePage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: pages[currentIndex],
      bottomNavigationBar: NavigationBar(
        selectedIndex: currentIndex,
        onDestinationSelected: (index) {
          setState(() {
            currentIndex = index;
          });
        },
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home),
            label: 'Home',
          ),
          NavigationDestination(
            icon: Icon(Icons.search_outlined),
            selectedIcon: Icon(Icons.search),
            label: 'Search',
          ),
          NavigationDestination(
            icon: Icon(Icons.favorite_border),
            selectedIcon: Icon(Icons.favorite),
            label: 'Favorites',
          ),
          NavigationDestination(
            icon: Icon(Icons.person_outline),
            selectedIcon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}

// ============================================================
// HOME PAGE
// ============================================================

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: const [
                    Text(
                      'Welcome Back!',
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.grey,
                      ),
                    ),
                    SizedBox(height: 5),
                    Text(
                      'Digital Library',
                      style: TextStyle(
                        fontSize: 27,
                        fontWeight: FontWeight.bold,
                        color: Color(0xff1E2A5A),
                      ),
                    ),
                  ],
                ),
                const CircleAvatar(
                  radius: 25,
                  backgroundColor: Color(0xffE3E7FF),
                  child: Icon(
                    Icons.person,
                    color: Color(0xff3F51B5),
                    size: 28,
                  ),
                ),
              ],
            ),

            const SizedBox(height: 25),

            // HOME SEARCH BAR
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 15),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(15),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.12),
                    blurRadius: 10,
                  ),
                ],
              ),
              child: TextField(
                readOnly: true,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const SearchPage(),
                    ),
                  );
                },
                decoration: const InputDecoration(
                  icon: Icon(Icons.search),
                  hintText: 'Search books, authors, topics...',
                  border: InputBorder.none,
                ),
              ),
            ),

            const SizedBox(height: 30),

            const Text(
              'Categories',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 15),

            SizedBox(
              height: 100,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: [
                  categoryCard(
                    context,
                    Icons.computer,
                    'Programming',
                  ),
                  categoryCard(
                    context,
                    Icons.science,
                    'Science',
                  ),
                  categoryCard(
                    context,
                    Icons.storage,
                    'Database',
                  ),
                  categoryCard(
                    context,
                    Icons.language,
                    'Networking',
                  ),
                ],
              ),
            ),

            const SizedBox(height: 25),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: const [
                Text(
                  'Popular Books',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),

            const SizedBox(height: 15),

            SizedBox(
              height: 310,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: books.length,
                itemBuilder: (context, index) {
                  return BookCard(book: books[index]);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget categoryCard(
    BuildContext context,
    IconData icon,
    String title,
  ) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => CategoryPage(
              category: title,
            ),
          ),
        );
      },
      child: Container(
        width: 105,
        margin: const EdgeInsets.only(right: 12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(15),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.12),
              blurRadius: 8,
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              color: Colors.indigo,
              size: 30,
            ),
            const SizedBox(height: 8),
            Text(
              title,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// BOOK CARD
// ============================================================

class BookCard extends StatefulWidget {
  final Book book;

  const BookCard({
    super.key,
    required this.book,
  });

  @override
  State<BookCard> createState() => _BookCardState();
}

class _BookCardState extends State<BookCard> {
  bool favorite = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => BookDetailsPage(
              book: widget.book,
            ),
          ),
        );
      },
      child: Container(
        width: 180,
        margin: const EdgeInsets.only(right: 15),
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.12),
              blurRadius: 10,
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            Stack(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Image.network(
                    widget.book.image,
                    height: 190,
                    width: double.infinity,
                    fit: BoxFit.cover,
                    errorBuilder: (
                      context,
                      error,
                      stackTrace,
                    ) {
                      return Container(
                        height: 190,
                        color: Colors.indigo.shade100,
                        child: const Center(
                          child: Icon(
                            Icons.menu_book,
                            size: 60,
                            color: Colors.indigo,
                          ),
                        ),
                      );
                    },
                  ),
                ),

                Positioned(
                  top: 8,
                  right: 8,
                  child: CircleAvatar(
                    backgroundColor: Colors.white,
                    radius: 18,
                    child: IconButton(
                      padding: EdgeInsets.zero,
                      iconSize: 20,
                      onPressed: () {
                        setState(() {
                          favorite = !favorite;
                        });
                      },
                      icon: Icon(
                        favorite
                            ? Icons.favorite
                            : Icons.favorite_border,
                        color: favorite
                            ? Colors.red
                            : Colors.grey,
                      ),
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 10),

            Text(
              widget.book.title,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),

            const SizedBox(height: 4),

            Text(
              widget.book.author,
              style: const TextStyle(
                color: Colors.grey,
                fontSize: 13,
              ),
            ),

            const SizedBox(height: 5),

            Row(
              children: [
                const Icon(
                  Icons.star,
                  color: Colors.amber,
                  size: 17,
                ),
                const SizedBox(width: 4),
                Text(
                  widget.book.rating.toString(),
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// SEARCH PAGE
// ============================================================

class SearchPage extends StatefulWidget {
  const SearchPage({super.key});

  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  String searchText = '';

  @override
  Widget build(BuildContext context) {
    List<Book> filteredBooks = books.where((book) {
      return book.title
              .toLowerCase()
              .contains(searchText.toLowerCase()) ||
          book.author
              .toLowerCase()
              .contains(searchText.toLowerCase()) ||
          book.category
              .toLowerCase()
              .contains(searchText.toLowerCase());
    }).toList();

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            const Text(
              'Search Books',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
                color: Color(0xff1E2A5A),
              ),
            ),

            const SizedBox(height: 20),

            TextField(
              onChanged: (value) {
                setState(() {
                  searchText = value;
                });
              },
              decoration: InputDecoration(
                hintText: 'Search books, authors, topics...',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: searchText.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          setState(() {
                            searchText = '';
                          });
                        },
                      )
                    : null,
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(15),
                  borderSide: BorderSide.none,
                ),
              ),
            ),

            const SizedBox(height: 20),

            Expanded(
              child: filteredBooks.isEmpty
                  ? const Center(
                      child: Text(
                        'No books found',
                        style: TextStyle(
                          fontSize: 18,
                          color: Colors.grey,
                        ),
                      ),
                    )
                  : ListView.builder(
                      itemCount: filteredBooks.length,
                      itemBuilder: (context, index) {
                        return SearchBookTile(
                          book: filteredBooks[index],
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// SEARCH BOOK TILE
// ============================================================

class SearchBookTile extends StatelessWidget {
  final Book book;

  const SearchBookTile({
    super.key,
    required this.book,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        contentPadding: const EdgeInsets.all(10),
        leading: ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: Image.network(
            book.image,
            width: 55,
            height: 70,
            fit: BoxFit.cover,
            errorBuilder: (
              context,
              error,
              stackTrace,
            ) {
              return Container(
                width: 55,
                height: 70,
                color: Colors.indigo.shade100,
                child: const Icon(
                  Icons.menu_book,
                  color: Colors.indigo,
                ),
              );
            },
          ),
        ),
        title: Text(
          book.title,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
        subtitle: Text(
          '${book.author}\n${book.category}',
        ),
        trailing: const Icon(
          Icons.arrow_forward_ios,
          size: 18,
        ),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => BookDetailsPage(
                book: book,
              ),
            ),
          );
        },
      ),
    );
  }
}

// ============================================================
// CATEGORY PAGE
// ============================================================

class CategoryPage extends StatelessWidget {
  final String category;

  const CategoryPage({
    super.key,
    required this.category,
  });

  @override
  Widget build(BuildContext context) {
    final categoryBooks = books
        .where(
          (book) =>
              book.category.toLowerCase() ==
              category.toLowerCase(),
        )
        .toList();

    return Scaffold(
      appBar: AppBar(
        title: Text(category),
        backgroundColor: Colors.indigo,
        foregroundColor: Colors.white,
      ),
      body: categoryBooks.isEmpty
          ? const Center(
              child: Text('No books available'),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(15),
              itemCount: categoryBooks.length,
              itemBuilder: (context, index) {
                return SearchBookTile(
                  book: categoryBooks[index],
                );
              },
            ),
    );
  }
}

// ============================================================
// BOOK DETAILS PAGE
// ============================================================

class BookDetailsPage extends StatelessWidget {
  final Book book;

  const BookDetailsPage({
    super.key,
    required this.book,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Book Details'),
        backgroundColor: Colors.indigo,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [

            ClipRRect(
              borderRadius: BorderRadius.circular(15),
              child: Image.network(
                book.image,
                height: 300,
                width: 220,
                fit: BoxFit.cover,
                errorBuilder: (
                  context,
                  error,
                  stackTrace,
                ) {
                  return Container(
                    height: 300,
                    width: 220,
                    color: Colors.indigo.shade100,
                    child: const Icon(
                      Icons.menu_book,
                      size: 100,
                      color: Colors.indigo,
                    ),
                  );
                },
              ),
            ),

            const SizedBox(height: 25),

            Text(
              book.title,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 26,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 8),

            Text(
              'by ${book.author}',
              style: const TextStyle(
                fontSize: 17,
                color: Colors.grey,
              ),
            ),

            const SizedBox(height: 15),

            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(
                  Icons.star,
                  color: Colors.amber,
                ),
                const SizedBox(width: 5),
                Text(
                  '${book.rating} / 5',
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),

            const SizedBox(height: 20),

            Container(
              padding: const EdgeInsets.symmetric(
                horizontal: 15,
                vertical: 8,
              ),
              decoration: BoxDecoration(
                color: Colors.indigo.shade50,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(
                book.category,
                style: const TextStyle(
                  color: Colors.indigo,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),

            const SizedBox(height: 25),

            const Align(
              alignment: Alignment.centerLeft,
              child: Text(
                'About this book',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),

            const SizedBox(height: 10),

            Text(
              book.description,
              style: const TextStyle(
                fontSize: 16,
                height: 1.6,
                color: Colors.black87,
              ),
            ),

            const SizedBox(height: 30),

            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton.icon(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ReadingPage(
                        book: book,
                      ),
                    ),
                  );
                },
                icon: const Icon(Icons.menu_book),
                label: const Text(
                  'Read Book',
                  style: TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.indigo,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// READING PAGE WITH TOPIC SEARCH
// ============================================================

class ReadingPage extends StatefulWidget {
  final Book book;

  const ReadingPage({
    super.key,
    required this.book,
  });

  @override
  State<ReadingPage> createState() => _ReadingPageState();
}

class _ReadingPageState extends State<ReadingPage> {
  String searchText = '';

  @override
  Widget build(BuildContext context) {

    final filteredTopics = widget.book.topics.where((topic) {
      return topic.title
          .toLowerCase()
          .contains(searchText.toLowerCase());
    }).toList();

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.book.title),
        backgroundColor: Colors.indigo,
        foregroundColor: Colors.white,
      ),

      body: SafeArea(
        child: Column(
          children: [

            // ==================================================
            // TOPIC SEARCH BAR
            // ==================================================

            Padding(
              padding: const EdgeInsets.fromLTRB(
                20,
                15,
                20,
                5,
              ),
              child: TextField(
                onChanged: (value) {
                  setState(() {
                    searchText = value;
                  });
                },
                decoration: InputDecoration(
                  hintText: 'Search topic...',
                  prefixIcon: const Icon(
                    Icons.search,
                    color: Colors.indigo,
                  ),
                  suffixIcon: searchText.isNotEmpty
                      ? IconButton(
                          icon: const Icon(Icons.clear),
                          onPressed: () {
                            setState(() {
                              searchText = '';
                            });
                          },
                        )
                      : null,
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                    borderSide: BorderSide.none,
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                    borderSide: BorderSide(
                      color: Colors.grey.shade200,
                    ),
                  ),
                ),
              ),
            ),

            const SizedBox(height: 10),

            // ==================================================
            // TOPIC CONTENT
            // ==================================================

            Expanded(
              child: filteredTopics.isEmpty
                  ? const Center(
                      child: Text(
                        'No topic found',
                        style: TextStyle(
                          fontSize: 18,
                          color: Colors.grey,
                        ),
                      ),
                    )
                  : SingleChildScrollView(
                      padding: const EdgeInsets.fromLTRB(
                        25,
                        10,
                        25,
                        30,
                      ),
                      child: Column(
                        crossAxisAlignment:
                            CrossAxisAlignment.start,
                        children: [

                          Text(
                            widget.book.title,
                            style: const TextStyle(
                              fontSize: 28,
                              fontWeight: FontWeight.bold,
                            ),
                          ),

                          const SizedBox(height: 10),

                          Text(
                            '${filteredTopics.length} Topics',
                            style: TextStyle(
                              fontSize: 18,
                              color: Colors.indigo.shade700,
                              fontWeight: FontWeight.bold,
                            ),
                          ),

                          const SizedBox(height: 20),

                          ...filteredTopics.map(
                            (topic) => topicSection(topic),
                          ),

                          const SizedBox(height: 25),

                          Center(
                            child: ElevatedButton.icon(
                              onPressed: () {
                                ScaffoldMessenger.of(context)
                                    .showSnackBar(
                                  const SnackBar(
                                    content: Text(
                                      'You have reached the end of this chapter.',
                                    ),
                                  ),
                                );
                              },
                              icon: const Icon(Icons.check),
                              label: const Text(
                                'Finish Reading',
                              ),
                              style: ElevatedButton.styleFrom(
                                backgroundColor:
                                    Colors.indigo,
                                foregroundColor: Colors.white,
                                padding:
                                    const EdgeInsets.symmetric(
                                  horizontal: 25,
                                  vertical: 14,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }

  // ==========================================================
  // TOPIC SECTION
  // ==========================================================

  Widget topicSection(Topic topic) {
    return Container(
      margin: const EdgeInsets.only(bottom: 25),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [

          Text(
            topic.title,
            style: const TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
            ),
          ),

          const SizedBox(height: 12),

          Text(
            topic.content,
            style: const TextStyle(
              fontSize: 17,
              height: 1.8,
              color: Colors.black87,
            ),
          ),

          const SizedBox(height: 18),

          Divider(
            color: Colors.grey.shade300,
          ),
        ],
      ),
    );
  }
}

// ============================================================
// FAVORITES PAGE
// ============================================================

class FavoritesPage extends StatelessWidget {
  const FavoritesPage({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            const Text(
              'My Favorites',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
                color: Color(0xff1E2A5A),
              ),
            ),

            const SizedBox(height: 20),

            Expanded(
              child: ListView.builder(
                itemCount: 3,
                itemBuilder: (context, index) {
                  return SearchBookTile(
                    book: books[index],
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// PROFILE PAGE
// ============================================================

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [

            const SizedBox(height: 20),

            const CircleAvatar(
              radius: 55,
              backgroundColor: Color(0xffE3E7FF),
              child: Icon(
                Icons.person,
                size: 65,
                color: Colors.indigo,
              ),
            ),

            const SizedBox(height: 15),

            const Text(
              'Library User',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 5),

            const Text(
              'reader@example.com',
              style: TextStyle(
                color: Colors.grey,
                fontSize: 15,
              ),
            ),

            const SizedBox(height: 30),

            profileOption(
              Icons.person_outline,
              'Edit Profile',
            ),

            profileOption(
              Icons.bookmark_border,
              'My Books',
            ),

            profileOption(
              Icons.history,
              'Reading History',
            ),

            profileOption(
              Icons.settings_outlined,
              'Settings',
            ),

            profileOption(
              Icons.help_outline,
              'Help & Support',
            ),

            profileOption(
              Icons.logout,
              'Logout',
            ),
          ],
        ),
      ),
    );
  }

  Widget profileOption(
    IconData icon,
    String title,
  ) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
      ),
      child: ListTile(
        leading: Icon(
          icon,
          color: Colors.indigo,
        ),
        title: Text(
          title,
          style: const TextStyle(
            fontWeight: FontWeight.w500,
          ),
        ),
        trailing: const Icon(
          Icons.arrow_forward_ios,
          size: 16,
        ),
        onTap: () {},
      ),
    );
  }
}